require('dotenv').config()
const { Server } = require('@modelcontextprotocol/sdk/server/index.js')
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js')
const { CallToolRequestSchema, ListToolsRequestSchema } = require('@modelcontextprotocol/sdk/types.js')
const http = require('http')

const PORT = process.env.PORT || 3333
const HOST = 'localhost'

// ─── Consome a rota SSE /pipeline/stream ──────────────────────────
// Retorna { result, progressLog } onde progressLog é array de msgs
function callPipelineStream(body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body)
    const progressLog = []
    let resultData = null
    let buffer = ''

    const req = http.request(
      {
        hostname: HOST,
        port: PORT,
        path: '/pipeline/stream',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
        },
      },
      (res) => {
        res.setEncoding('utf8')

        res.on('data', (chunk) => {
          buffer += chunk

          // processa linhas SSE completas
          const lines = buffer.split('\n')
          buffer = lines.pop() // guarda linha incompleta

          for (const line of lines) {
            if (!line.startsWith('data: ')) continue
            const raw = line.slice(6).trim()
            if (raw === '[DONE]') continue

            try {
              const event = JSON.parse(raw)

              if (event.type === 'progress') {
                progressLog.push(event.msg)
                // ecoa no stderr para aparecer nos logs do pm2
                process.stderr.write(event.msg + '\n')
              }

              if (event.type === 'result') {
                resultData = event.content
              }

              if (event.type === 'error') {
                reject(new Error(event.message))
              }
            } catch (_) {
              // linha SSE malformada — ignora
            }
          }
        })

        res.on('end', () => {
          if (resultData) {
            resolve({ result: resultData, progressLog })
          } else {
            reject(new Error('Pipeline não retornou resultado'))
          }
        })
      }
    )

    req.on('error', reject)
    req.write(payload)
    req.end()
  })
}

// ─── MCP SERVER ───────────────────────────────────────────────────
const server = new Server(
  { name: 'ai-core', version: '4.0.0' },
  { capabilities: { tools: {} } }
)

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: 'ai_core_pipeline',
      description: 'Pipeline de 6 estágios com contexto semântico dos repositórios. Use para implementações complexas, análise de arquitetura, refatorações e correções de bugs. Sempre use esta tool quando o usuário pedir para implementar, corrigir ou analisar código.',
      inputSchema: {
        type: 'object',
        properties: {
          prompt:    { type: 'string', description: 'Tarefa, pergunta ou contexto extraído de imagem' },
          sessionId: { type: 'string', description: 'ID de sessão (opcional)' },
          useVector: { type: 'boolean', description: 'Usar busca vetorial Qdrant' },
        },
        required: ['prompt'],
      },
    },
  ],
}))

server.setRequestHandler(CallToolRequestSchema, async (req) => {
  const { name, arguments: args } = req.params

  if (name === 'ai_core_pipeline') {
    const { prompt, sessionId, useVector = false } = args

    const { result, progressLog } = await callPipelineStream({ prompt, sessionId, useVector })

    // ── Monta o texto de progresso visível no opencode ──────────
    const progressSection = progressLog.length > 0
      ? `\n\n---\n**🔄 Pipeline executado — etapas:**\n${progressLog.map(l => `> ${l}`).join('\n')}\n---\n`
      : ''

    // ── Monta o conteúdo final que o opencode vai exibir ────────
    const summaryLines = [
      `**Rota:** ${result.pipeline ? Object.keys(result.pipeline).join(' → ') : 'N/A'}`,
      `**Premium:** ${result.premium_activated ? 'Sim ✨' : 'Não'}`,
      `**Tempo total:** ${result.total_ms ? (result.total_ms / 1000).toFixed(1) + 's' : 'N/A'}`,
      `**Contexto:** ${result.context?.contextSize ?? 'N/A'} chars`,
    ]

    if (result.timings) {
      const timingLines = Object.entries(result.timings)
        .map(([k, v]) => `  - ${k}: ${(v / 1000).toFixed(1)}s`)
        .join('\n')
      summaryLines.push(`**Timings:**\n${timingLines}`)
    }

    const fullText = `${progressSection}\n${summaryLines.join('\n')}\n\n---\n\n${result.answer ?? ''}`

    return {
      content: [{ type: 'text', text: fullText }],
    }
  }

  throw new Error(`Tool desconhecida: ${name}`)
})

const transport = new StdioServerTransport()
server.connect(transport).then(() => {
  process.stderr.write('ai-core MCP server v4.0 pronto (stream mode)\n')
})
